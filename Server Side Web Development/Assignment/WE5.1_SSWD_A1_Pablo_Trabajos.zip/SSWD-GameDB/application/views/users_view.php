<?php
  // Encode to JSON and output
  echo json_encode($users);
?>
